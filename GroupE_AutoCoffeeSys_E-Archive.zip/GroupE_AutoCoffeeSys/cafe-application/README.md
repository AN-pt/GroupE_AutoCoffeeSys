# GroupE_AutoCoffeeSys
The core objective of this project is to usher in a new era of efficiency and convenience in privately-owned coffee shops, especially the smaller ones. With this automation in place, coffee shops can bid farewell to paper-based chaos and manual order management.
