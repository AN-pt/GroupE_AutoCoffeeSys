from cafe_application.src.main.CafeApplication import main

if __name__ == '__main__':
    main()
